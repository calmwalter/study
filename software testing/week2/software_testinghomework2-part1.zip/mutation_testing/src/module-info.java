module mutation_testing {
	requires junit;
}